def handler(event, context):
    return "This is a test function."

if __name__ == "__main__":
    pass